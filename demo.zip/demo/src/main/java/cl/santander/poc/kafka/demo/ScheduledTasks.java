package cl.santander.poc.kafka.demo;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ScheduledTasks {

	private final ServiceConsumer serviceConsumer;

	public ScheduledTasks(ServiceConsumer serviceConsumer) {
		this.serviceConsumer = serviceConsumer;
	}

	@Scheduled(fixedRate = 180000) // 180000 milisegundos = 3 minutos
	public void reprocessUnacknowledgedMessagesTask() {
		// Lógica para ejecutar la función cada 3 minutos
		serviceConsumer.reprocessAllUnacknowledgedMessages();
	}
}
