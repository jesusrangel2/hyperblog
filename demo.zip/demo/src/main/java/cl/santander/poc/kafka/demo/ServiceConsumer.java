package cl.santander.poc.kafka.demo;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ServiceConsumer {

	ObjectMapper objectMapper = new ObjectMapper();

	@PostConstruct
	private void init() {
		objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		objectMapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
		objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

	}

	private Map<Integer, List<DemoMessage>> unacknowledgedMessages = new HashMap<>();

	@KafkaListener(topics = "${kafka.topic}")
	public void receive(String kafkaMessage, Acknowledgment ack,
			@Header(name = KafkaHeaders.RECEIVED_KEY, required = false) Integer key,
			@Header(KafkaHeaders.RECEIVED_PARTITION) Integer partition, @Header(KafkaHeaders.OFFSET) Integer offset)
			throws JsonMappingException, JsonProcessingException {

		// Mapear el mensaje al objeto para trabajar mas facil en el camino
		DemoMessage demoMessage = objectMapper.readValue(kafkaMessage, DemoMessage.class);
		demoMessage.setKey(key);
		demoMessage.setAck(ack);
		demoMessage.setOffset(offset);
		demoMessage.setPartition(partition);
		demoMessage.setDate(new Date());

		log.info("Demo Message is {}", demoMessage);

		// cada mensaje que llega se almacena
		storeUnacknowledgedMessage(key, demoMessage);

	}

	private void storeUnacknowledgedMessage(Integer key, DemoMessage message) {

		System.out.println("before add " + unacknowledgedMessages);
		// revisar el mapa de mensajes si ya hay uno con el key obtener la lista y
		// agregarlo en caso de que no este
		if (unacknowledgedMessages.containsKey(key)) {
			List<DemoMessage> list = unacknowledgedMessages.get(key);
			if (!list.contains(message)) {
				list.add(message);
				unacknowledgedMessages.put(key, list);
			}
		} else {
			// agregar mensaje nuevo a la lista de cosas que procesar
			List<DemoMessage> list = new ArrayList<>();
			list.add(message);
			unacknowledgedMessages.put(key, list);
		}

		System.out.println("after add " + unacknowledgedMessages);
	}

	public void reprocessAllUnacknowledgedMessages() {
		System.out.println("reprocesando mensajes");
		System.out.println("reprocesando mensajes" + unacknowledgedMessages);
		for (List<DemoMessage> messagesToReprocess : unacknowledgedMessages.values()) {

			if (messagesToReprocess.get(messagesToReprocess.size() - 1).getEvent() == 5) {
				// se busca el ultimo mensaje contemplando que el utlimo evento sea el id 5 y se
				// envian todos los ack de esa transaccion
				messagesToReprocess.parallelStream().forEach(m -> m.getAck().acknowledge());
				unacknowledgedMessages.remove(messagesToReprocess.get(0).getKey());
			}
			
			//if ultimo evento es error de abono
			
			//if ultimo evento es error de reversa
			
			//if ultimo evento es error de consulta a getnet

			// tomar decisiones segun la cantidad de mensajes que tengamos y el evento donde
			// se quedo y ejecutar el ack de ese listado de mensajes
			
			for (DemoMessage demoMessage : messagesToReprocess) {
				
				demoMessage.getAck().acknowledge();

			}

		}

	}

}
