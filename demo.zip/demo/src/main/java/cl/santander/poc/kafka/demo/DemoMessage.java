package cl.santander.poc.kafka.demo;

import java.io.Serializable;
import java.util.Date;

import org.springframework.kafka.support.Acknowledgment;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class DemoMessage implements Serializable {

	private static final long serialVersionUID = -6378414217955491126L;
	private Integer event;
	private String rut;
	private Integer key;
	private Integer status;
	private String message;
	private Acknowledgment ack;
	private Integer partition;
	private Integer offset;
	private Date date;
}
